# Coverage reconstruction from raw/ chunk files (2026-09-09)

Each raw file records one chunk (counter_start..counter_end, tested, hits). Phases are ordered by rule strictness; a later, stricter rule may resume where an earlier rule found no hit, since anything the weaker rule rejected is rejected by the stricter one too.

## d = -301
phase v1-rule [v1 filter]: chunks 1335, covered 0..85439
phase t<0 [v1 filter + t<0]: chunks 133, covered 85440..93951
phase q300 [v1 filter + bitlen(q)=300]: chunks 2384, covered 93952..246527
hits v1-rule phase: [(84672, 84735)] (c=84722, q has 299 bits: fails bitlen(q)=300); t<0 phase: []; q300 phase: [(246464, 246527)]
=> under bitlen(q)=300 the smallest valid c for d=-301 is 246492 iff coverage 0..246527 is gap-free: YES

## d = 89
phase v1-rule [v1 filter]: chunks 1072, covered 0..68607
hits: [(68544, 68607)] ; smallest valid c under v1 rule = 68592, and it satisfies bitlen(q)=300, so it is also the smallest under the stricter rule: YES

## d = 145 (paused)
phase v1-rule [v1 filter]: covered 0..14207 contiguous; single hit c=13201 (q 299 bits, fails bitlen(q)=300)
phase t<0 [v1 filter + t<0]: restarted at 0, covered 0..12287 contiguous, no hit
phase q300 [v1 filter + bitlen(q)=300]: resumed at 10496, covered 10496..99007 contiguous, no hit
=> union under the strictest rule: 0..99007 gap-free, no valid c; search paused at 99008.

## Control run for the audit abort behaviour
control_recover0.gp: with default(recover, 0) a deliberately failing must() aborts gp (exit code 1) before the pass
marker is written (control_recover0_out.txt contains only before_failing_check=1). The same script with the gp
default recover=1 continues and writes audit_pass=1 (control_recover1_out.txt). This is the failure mode of the
2026-09-09 first d=89 audit; the v2 template sets recover=0.
