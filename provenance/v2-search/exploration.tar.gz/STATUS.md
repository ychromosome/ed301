# ED301-v2 explorative curve search, 2026-09-09

Explorative pre-work (disclosed). The formal confirmation run must follow a pre-published rule file.

Field: p = 2^301 - 2^89 + 907 (proven prime, p = 3 mod 8). Rule: s = 907 + c, a = s^2 mod p, smallest valid c;
v1 filter (both orders 4*prime, twist-secure, Montgomery-compatible, |D_K| > 2^100, MOV-small check).
d = 301 impossible (square mod p). Extra rule (Emmy 2026-09-09, confirmed by Martin): bitlen(q) = 300, i.e. N = 4q >= 2^301 (equivalently
t <= -2^89 + 908). t < 0 alone is NOT sufficient because p + 1 < 2^301. This keeps the v1 non-neutral-key
proof unchanged (every pruned scalar s < 2^301 <= 4q).

| d | smallest c, v1 rule | t sign | q bits | under the 300-bit rule |
|---|---|---|---|---|
| 145 | 13201 (s 14108, a 199035664) | + | 299 | rejected (q 299 bits); q300 search running |
| 89 | 68592 (s 69499, a 4830111001) | - | 300 | accepted; full audit running |
| -301 | 84722 (s 85629, a 7332325641) | + | 299 | rejected (q 299 bits); q300 search resumed |

Files: search_d*.log/.jsonl (v1 rule), search_negt_d*.log (t<0 rule), hit_d*.json, audit_d89_c68592_*.
Incident: the plain-rule -301 run finished (SUMMARY present) before a pkill of mine killed the tool shell.

## Decision 2026-09-09 (Martin)

Extra search rule confirmed in its precise form (Emmy): the main subgroup order q must have exactly 300 bits
(N = 4q >= 2^301, equivalently t <= -2^89 + 908). Rationale: keeps the v1 non-neutral-key proof
(every pruned scalar s < 2^301 <= 4q); stricter than Ed448 itself (Ed448's 4L lies inside its pruning range,
Ed25519's 8L does not) while leaving the RFC 8032 procedure (pruning, encoding, dom4, SHAKE256,
cofactored verification) untouched. Being stricter is acceptable as long as it stays standard-conformant.
Searches with this rule: search_q300_d145 (resumed at 10496), search_q300_d-301 (resumed at 93952);
d=89 c=68592 already satisfies it (q has 300 bits), audit running.

## Audit rule set (2026-09-09, evening)

The v1 audit script hard-coded two v1 *observations* as musts: maximal embedding degrees (k = q-1, k = qt-1)
and Frobenius conductor f = 2. Neither is part of the v1 acceptance rule (KURVENBERICHT Pruefvektor: no
embedding degree k <= 100; |D_K| > 2^100). Ed25519 has k = (l-1)/6, Ed448 k = (l-1)/2. The v2 audit enforces
exactly the search rule (k > 100, |D_K| > 2^100) and reports the exact k, (order-1)/k and f as information.
The SafeCurves-style floor k >= (order-1)/100 is reported, not enforced, so that search rule and audit rule
stay identical. d=89 c=68592: k_q = q-1 (300 bits), k_qt = (qt-1)/73 (293 bits); both factorisations proven.

## Audit result d=89 c=68592 (2026-09-09, evening)

audit_pass=1 with the v2 audit rule set (search rule enforced, v1 observations reported).
SEA counts reproduced (curve 5.2 s, twist 4.4 s); q-1 and qt-1 fully factored and proven;
k_q = q-1 (300 bits), k_qt = (qt-1)/73 (293 bits); rho ~149.5 bits both groups; Hasse, non-anomalous,
non-supersingular, j not 0/1728; |D_K| 294 bits, Frobenius conductor 14. File:
audit_d89_c68592_security_parameters_pari.txt. Searches under the 300-bit rule: d=145 through ~69k, d=-301
through ~154k, no hits yet.

## 2026-09-09 late: d=145 paused, d=-301 boosted (Martin)

d=145 (q300 rule) paused at contiguous c = 97727, resume point in resume_q300_d145.txt, no hits.
d=-301: first driver (10 workers) continues from ~184k; second driver (20 workers, search_v2_q300b.py,
own jsonl) started at c = 196928. The second driver briefly ran with the shared jsonl name and truncated
search_q300_d-301.jsonl; the authoritative per-chunk record is raw/search_q300_d-301_<start>_<end>_worker_*.txt
plus the CHUNK lines in search_q300_d-301.log. Contiguity is reconstructed from raw/ at the end.

## d=-301 hit under the 300-bit rule (2026-09-09, late)

c = 246492, s = 247399, a = 61206265201 (36 bits), t < 0, q 300 bits, qt 299 bits, |D_K| 290 bits.
Coverage under the q300 rule from 93952 to 246527 is complete (raw/ chunk files), below 93952 the t<0 run
(85440..93951) and the v1-rule run (0..85439, single hit 84722 with q of 299 bits) found no valid c.
Full audit running: audit_v2_d-301_c246492.*. Searches for d=-301 stopped after the hit.

## Clean audits (2026-09-09, late): both candidates pass

Template audit_v2_template.gp (recover=0, search rule enforced, v1 observations reported). Single pass marker,
zero user errors in both runs.

| | d=89 c=68592 | d=-301 c=246492 |
|---|---|---|
| q, qt | proven prime, 300 / 299 bits | proven prime, 300 / 299 bits |
| SEA reproduced | yes | yes |
| k_q, k_qt | q-1, (qt-1)/73 | (q-1)/4, (qt-1)/2 (298 bits each) |
| rho, negation-map model | 149.326 bits | 149.326 bits |
| |D_K| bits, Frobenius conductor | 294, 14 | 290, 94 |
| SafeCurves floor (informational) | pass | pass |

Files: audit_v2_d89_c68592_pari.txt, audit_v2_d-301_c246492_pari.txt (+ .gp, .log). Martin leans to d=-301.

## Decision 2026-09-09 (Martin, recorded by Emmy): d = -301, c = 246492, a = 247399^2 = 61206265201

Rule-file draft: REGELDATEI_ED301-v2_ENTWURF.md (publish only after points 5/6 are fixed; external
timestamp before the confirmation run). Proposal for points 5, 6, 7:
~/Dokumente/ED301/VORSCHLAG_PUNKTE_5_6_7_ED301-v2_2026-09-09.md. Consolidated values:
ED301-v2_candidate_values.json.

## 2026-09-09 night: Emmy's four pre-publication points (all fixed)

1. Driver: search_v3.py counts a chunk as completed only with exit 0, no PARI error line and an existing
   raw file; any failure -> status=FATAL in SUMMARY and driver exit 1 (tested with d=301: FATAL, exit 1).
2. Audit: audit_v3_template.gp takes the candidate from the environment (ED301_D/C/Q/QT/OUT), enforces
   criterion 5 (bitlen(q)=300, 4q>=2^301, bitlen(qt)>=299) as a must and emits the bit lengths.
3. Rule file section 3 and the proposal table now list the same nine criteria in the worker's check
   order (search_worker_v3.gp; bit lengths before primality). Worker v3 re-found c=246492 on its chunk.
4. Wording: conductor statement limited to "the conservative bound needs no f=2", primality (isprime)
   separated from the pending ECPP certificates, criterion 5 names both subgroup bit lengths.
Superseded: search_worker_v2_q300.gp / search_v2_q300.py / audit_v2_template.gp (kept for the record).
