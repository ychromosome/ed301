\\ Control run: with default(recover, 0) a failed must() must abort the script
\\ before any pass marker is written.
default(recover, 1);
out = fileopen("control_recover1_out.txt", "w");
must(c, m) = { if (!c, error(m)); };
filewrite(out, "before_failing_check=1");
must(1 == 2, "deliberate failure");
filewrite(out, "audit_pass=1");
fileclose(out);
quit;
