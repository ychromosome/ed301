# ED301-v2 A2 confirmation run

Status: **A2–A6 local checks completed; preparing the Gate-A review package.**
External Gate A review is still pending; Phase B has not started.

- Source: signed tag `v2-search-rule-2026-09-09`, tag object
  `6d48ac5f584263c7fde3afd347c9b93debe3b224`, commit
  `0bf9b5936737fc920d701815cf55cfd35c54d288`.
- Manifest SHA-256:
  `a9c210823af851675678117d401415b54c2ad0cad8bb4ab47ce94f669acae313`.
- Martin explicitly waived OpenTimestamps/Bitcoin and authorized GitHub
  prerelease publication followed by A2. No OTS proof is claimed.
- GitHub release ID: `385742722`.
- Release URL: https://github.com/ychromosome/ed301/releases/tag/v2-search-rule-2026-09-09
- Server `published_at`: **2026-09-09T18:11:30Z**.
- A2 actual process start: **2026-09-09T18:14:16Z** (20:14:16 CEST), after publication.
- A2 actual process exit: **2026-09-09T18:58:03Z** (20:58:03 CEST), exit status 0.
- A2 elapsed time: **43 minutes 47 seconds**.
- User service: `ed301-v2-a2-20260909-fmyuld.service`.
- Invocation ID: `c2c85daf9a264881865b65f7898ef2d1`.
- Initial main PID: `434820`; use the service state, not a stale PID, for control.

The A2 process ran independently of the tool session and has now exited. The
service remains `active (exited)` to retain its exit metadata; that does not
mean GP workers are still running. Do not rerun over this directory or stop
unrelated PARI/GP processes.

The execution directory contains only the four bound files before startup;
their hashes and the full exported 17-entry manifest were checked. The source
files are read-only. The original signed package remains unchanged; the
publication-policy amendment is separately documented on `Testing` at commit
`7e00e5c270086a588a6a42c58fe1c575f2985e68` and in the release notes.

Command:

```text
/usr/bin/python3 search_v3.py --d -301 --start 0 --chunk 64 --workers 10 --maximum 1000000 --out raw_v3
```

Working directory:
`/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/run`.

Evidence and live logs:

- `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/evidence/github-release-before-start.json`
- `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/evidence/pre-run-verification.json`
- `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/evidence/systemd-after-start.txt`
- `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/evidence/driver.stdout.log`
- `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/evidence/driver.stderr.log`
- `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/run/raw_v3/search_v3_d-301_from0.jsonl`

## A2 final acceptance

The independent read-only record checker passed:

- 3858 complete blocks, all metadata and raw hit arrays matched to the JSONL log.
- Gap-free coverage of counters **0..246911**, totaling 246912 tested counters.
- No failed blocks, no driver stderr, one final `status=OK` summary.
- Exactly one valid hit, at **c=246492** in block **246464..246527**.
- All 14 candidate values agree with the disclosed prediction.
- The numerically smallest hit was checked independently of textual sorting.

Result: `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/evidence/A2_RESULT.json`.
Checker: `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/evidence/verify_a2_records.py`.
Exit metadata: `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/evidence/systemd-a2-completed.txt`.

## A3 and subsequent proof work

A3 used the candidate values from the accepted fresh A2 result. Its process ran
from 2026-09-09T19:02:30Z to 19:02:43Z and exited 0. Both curve orders were
recounted, all required reported conditions were checked, and the output has
exactly one final pass marker. Only the expected two stack-size warnings occur
on stderr.

Audit: `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/audit/audit_v3_d-301_c246492_pari.txt`.
Acceptance: `/home/martin/Dokumente/ED301/ED301-v2_A2_2026-09-09_fmYuLD/evidence/A3_RESULT.json`.

The ECPP certificates for p, q and q_twist have been generated and independently
checked in Python, including complete trial division of the terminal primes.
The additional N-minus-1/BLS certificates for q and q_twist and the independent
curve/twist order witnesses also passed. The v2 basepoint was derived at counter
0 in Python; its PARI cross-check passed, including [4]P=G and exact order q.
The parameter JSON and specification passed their consistency checks, and the
complete local Gate-A replay passed. These local successes do not constitute
external Gate A approval.

The first adapted certificate-export helper had a GP multiline-syntax error;
those attempts exited 1 without pass markers. Its original source and failed
logs are retained separately. The corrected export attempts completed normally.
The signed search tools, A2 data and A3 audit were not modified by that correction.
