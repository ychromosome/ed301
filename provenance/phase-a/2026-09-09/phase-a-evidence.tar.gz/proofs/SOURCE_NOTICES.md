# Phase-A proof sources and adaptations

Copyright 2026 Martin Wolf and ED301 contributors. Project-authored material
is supplied under Apache-2.0, subject to the existing source notices retained
in the signed source snapshot. Mathematical facts are not claimed as copyrightable.
No PARI, OpenSSL, Python or other third-party binary distribution is vendored.

The A2/A3 tools are the unchanged files from the signed pre-run package. These
v1 proof tools were reused for the post-run checks, with their original source
SHA-256 recorded before adaptation:

| v1 source | Original SHA-256 | Current use |
|---|---|---|
| verify_c44730_ecpp_independent.py | bd6970ccefaf1f36cf7df56cd61c1be7b0186f42faa66196bd7a5024fc437db4 | ECPP verification |
| verify_c44730_nminus1_bls_independent.py | 1ebf23167028a927b61783c9fab9bdcbd1d9f9fbe04daf22ba456579426e63a1 | N-1/BLS verification |
| audit_candidate_c44730_order_witness.py | 488c7bc3887870033b6e1d1be4d934f645df9c95265f16e2bd7be2fd341ca258 | independent main/twist order witnesses |
| derive_c44730_basepoint.py | 6b6b1ad194a38b3afff5beff08c042f8aec2221d7e0c49459a3d8db7655b02b4 | deterministic basepoint derivation |
| phase_a_primecert.gp | 32a58e83fbf868341d5b00a41b546dc411357251b4fa18b9bb423fdbb8f1127f | certificate-generation workflow |
| verify_c44730_basepoint_pari.gp | dc485dd2a58f226afa00712dfc213c2603f58a9e5518f896dcdaeb56e4225cf6 | PARI model/order cross-check |

Changes are limited to v2 parameter binding and proof robustness:

- Order/basepoint tools read the accepted fresh A2 candidate through
  confirmed_parameters.py, which checks derivation, model and size relations
  but does not itself replace primality proofs.
- The basepoint DST is v2; field-specific explanatory values are derived from
  the new modulus. Affine point operations and hash-and-increment are inherited.
- Certificate verifiers require the expected A2 prime as an explicit argument.
  The ECPP checker also rejects invalid theorem inputs and nonunit/ambiguous
  intermediate projective operations over the not-yet-proven root. Terminal
  primes remain proven by complete trial division.
- The N-1/BLS verifier retains the v1 deterministic unsigned-64-bit Miller-Rabin
  leaf test and Pocklington/BLS checks; expected-root binding was added.
- Generation follows primecert/primecertexport with fatal GP errors, one explicit
  root and fresh output files. The first export wrapper's syntax error is
  preserved under scripts/history and logs, not counted as a passed proof.
- The PARI basepoint wrapper retains the v1 mapping/ellmul/ellorder checks and
  also compares [4]P with G. Its initial min/max call was corrected to vecmin/vecmax.
- A2/A3 record checks and A6 consistency checks use standard-library parsing
  and integer operations; they are evidence checkers, not production wire parsers.

Current sources and results are bound by the final review-package manifest.
These are post-run proof/checking tools, not tools claimed to have been committed
before the search. The selection rule and basepoint algorithm were already
fixed in the signed pre-run package.
