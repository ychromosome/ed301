"""Build the v2 parameter data from accepted A2, fresh A3 and checked A5 artifacts."""

import hashlib
import json
from pathlib import Path

from confirmed_parameters import load_candidate

root = Path(__file__).resolve().parents[2]
c = load_candidate(root / "evidence/A2_RESULT.json")
a2_result = json.loads((root / "evidence/A2_RESULT.json").read_text())
a3_result = json.loads((root / "evidence/A3_RESULT.json").read_text())
b = json.loads((root / "proofs/BASEPOINT.json").read_text())
audit = dict(line.split("=", 1) for line in
             (root / "audit/audit_v3_d-301_c246492_pari.txt").read_text().splitlines())
p, a, d, q, qt = (c[name] for name in ("p", "a", "d", "q", "qt"))
A, B = c["A"], c["B"]
a2, a4 = A*B % p, B*B % p
t4x = pow(c["s"], -1, p)
A24 = (A - 2)*pow(4, -1, p) % p

if a2_result["status"] != "PASS" or a3_result["status"] != "PASS":
    raise ValueError("upstream phase has not passed")
if not b["status"].startswith("Python derivation and PARI"):
    raise ValueError("basepoint cross-check is not complete")
if b["order"] != str(q) or int(b["basepoint"]["x"]) >= p or int(b["basepoint"]["y"]) >= p:
    raise ValueError("basepoint parameter mismatch")

certificate_names = ["p_ecpp_internal.pari", "q_ecpp_internal.pari",
                     "q_twist_ecpp_internal.pari", "q_nminus1_bls_internal.pari",
                     "q_twist_nminus1_bls_internal.pari"]
certificates = {name: hashlib.sha256((root / "proofs/certificates" / name).read_bytes()).hexdigest()
                for name in certificate_names}

data = {
    "schema": "ED301-parameter-set-v2",
    "status": "mathematical-evidence-package-awaiting-gate-A-review; not a product release or standardized signature profile",
    "derivation": {
        "field_formula": "p = 2^301 - 2^89 + 907",
        "edwards_d_signed": "-301",
        "edwards_a_rule": "s=907+c; a=s^2 mod p; smallest c>=0 satisfying the nine published criteria",
        "first_passing_counter": str(c["c"]), "s": str(c["s"]), "a": str(a),
        "confirmation_covered_through": str(a2_result["covered_counters"][1]),
        "completed_blocks": a2_result["completed_blocks"],
        "signed_source_commit": "0bf9b5936737fc920d701815cf55cfd35c54d288",
        "signed_tag": "v2-search-rule-2026-09-09",
        "run_manifest_sha256": "a9c210823af851675678117d401415b54c2ad0cad8bb4ab47ce94f669acae313",
        "publication": {"release_id": 385742722, "published_at": "2026-09-09T18:11:30Z",
                        "url": "https://github.com/ychromosome/ed301/releases/tag/v2-search-rule-2026-09-09",
                        "ots_gate": "waived by Martin before A2; any later receipt is supplemental"},
        "A2_started_at": "2026-09-09T18:14:16Z", "A2_exited_at": "2026-09-09T18:58:03Z",
        "selection_scope": "confirmation after disclosed exploratory work, not an unseen first selection"
    },
    "field": {
        "p_decimal": str(p), "p_hex": format(p, "x"), "p_little_endian_hex": p.to_bytes(38, "little").hex(),
        "bit_length": p.bit_length(), "p_mod_4": p % 4, "p_mod_8": p % 8,
        "reduction_identity": "2^301 = 2^89 - 907 modulo p",
        "inversion_exponent": str(p-2), "square_root_exponent": str((p+1)//4),
        "square_root_ratio_exponent": str((p-3)//4),
        "formal_primality_proof": "ECPP certificate, PARI validation and independent Python validation with complete trial division at the terminal prime"
    },
    "edwards": {
        "equation": "a*x^2+y^2=1+d*x^2*y^2 over F_p",
        "a_decimal": str(a), "a_hex": format(a, "x"), "a_bit_length": a.bit_length(),
        "d_decimal": str(d), "d_hex": format(d, "x"), "d_signed": "-301",
        "a_legendre": 1, "d_legendre": -1, "addition_complete": True,
        "identity": {"x": "0", "y": "1"},
        "order_2_point": {"x": "0", "y": str(p-1)},
        "order_4_point": {"x": str(t4x), "y": "0", "derivation": "x=s^(-1) mod p"}
    },
    "group": {
        "order_N_decimal": str(c["N"]), "order_N_hex": format(c["N"], "x"),
        "factorization": "4*q", "cofactor_h": 4, "q_decimal": str(q), "q_hex": format(q, "x"),
        "q_little_endian_hex": q.to_bytes(38, "little").hex(), "q_bit_length": q.bit_length(),
        "q_log2": audit["log2_q"], "q_formally_prime": True, "abstract_group_cyclic": True,
        "frobenius_trace": str(c["t"]), "embedding_degree": audit["embedding_degree_q"],
        "embedding_degree_relation": "(q-1)/4",
        "negation_optimized_pollard_rho_log2_operations": audit["rho_negation_map_expected_bits_q"],
        "q_minus_1_factorization": [[str(f), e] for f, e in a3_result["factorizations"]["q"]]
    },
    "twist": {
        "non_square_z": "2",
        "weierstrass_equation": "Y^2=X^3+(2*A*B)*X^2+(4*B^2)*X over F_p",
        "weierstrass_coefficients": ["0", str(2*a2 % p), "0", str(4*a4 % p), "0"],
        "order_decimal": str(c["Nt"]), "order_hex": format(c["Nt"], "x"),
        "factorization": "4*q_twist", "cofactor": 4, "q_twist_decimal": str(qt),
        "q_twist_hex": format(qt, "x"), "q_twist_bit_length": qt.bit_length(),
        "q_twist_log2": audit["log2_qt"], "q_twist_formally_prime": True,
        "abstract_group_cyclic": True, "frobenius_trace": str(-c["t"]),
        "embedding_degree": audit["embedding_degree_qt"], "embedding_degree_relation": "(q_twist-1)/2",
        "negation_optimized_pollard_rho_log2_operations": audit["rho_negation_map_expected_bits_qt"],
        "q_minus_1_factorization": [[str(f), e] for f, e in a3_result["factorizations"]["qt"]]
    },
    "montgomery": {
        "equation": "B*v^2=u^3+A*u^2+u over F_p", "A_decimal": str(A), "A_hex": format(A,"x"),
        "B_decimal": str(B), "B_hex": format(B,"x"), "A24_convention": "minus",
        "A24_minus_decimal": str(A24), "A24_minus_hex": format(A24,"x"),
        "A24_plus_decimal": str((A24+1) % p),
        "ladder_doubling_formula": "z_2=E*(AA+A24_minus*E)"
    },
    "weierstrass": {
        "equation": "Y^2=X^3+(A*B)*X^2+B^2*X over F_p",
        "coefficients": ["0", str(a2), "0", str(a4), "0"],
        "j_invariant": audit["j"], "supersingular": False, "anomalous": False,
        "frobenius_discriminant": audit["frobenius_discriminant"],
        "fundamental_cm_discriminant": audit["fundamental_cm_discriminant"],
        "fundamental_cm_discriminant_bits": int(audit["fundamental_cm_discriminant_bitlength"]),
        "frobenius_conductor": audit["frobenius_conductor"],
        "possible_endomorphism_ring_conductors": [1,2,47,94],
        "endomorphism_ring_status": "actual endomorphism ring not identified; all conductor divisors are retained",
        "conservative_nonscalar_endomorphism_degree_lower_bound": audit["cm_nonscalar_degree_lower_bound"]
    },
    "basepoint": {
        "derivation_dst_ascii": b["dst"], "counter_encoding": "uint32 big endian",
        "first_counter": b["derivation_counter"], "xof": "SHAKE256", "xof_output_bytes": 38,
        "hash_input_hex": b["hash_input_hex"], "xof_output_hex": b["raw_shake256_38_hex"],
        "candidate_rule": "clear bits 301..303; reject y>=p or non-point; choose even x; G=[4]P; reject G=O; choose first surviving counter",
        "candidate_P_x_decimal": b["candidate"]["x"], "candidate_P_y_decimal": b["candidate"]["y"],
        "G_edwards_x_decimal": b["basepoint"]["x"], "G_edwards_y_decimal": b["basepoint"]["y"],
        "G_compressed_edwards_hex": b["basepoint"]["compressed_edwards_hex"],
        "G_montgomery_u_decimal": b["montgomery"]["u"], "G_montgomery_v_decimal": b["montgomery"]["v"],
        "G_montgomery_u_little_endian_hex": b["montgomery"]["u_le_hex"],
        "G_montgomery_v_little_endian_hex": b["montgomery"]["v_le_hex"], "exact_order": "q"
    },
    "encoding": {
        "field_bytes": 38, "field_byte_order": "little", "field_reserved_bits": [301,302,303],
        "point_bytes": 38, "point_y_bits": "0..300", "point_reserved_bits": [301,302],
        "point_x_sign_bit": 303, "point_sign_definition": "LSB of canonical x",
        "scalar_bytes": 38, "scalar_byte_order": "little", "signature_scalar_range": "0 <= S < q",
        "scope": "Curve encodings; external X301-u acceptance is a separate profile decision"
    },
    "evidence": {
        "A2_result_sha256": hashlib.sha256((root/'evidence/A2_RESULT.json').read_bytes()).hexdigest(),
        "A3_report_sha256": a3_result["report_sha256"],
        "basepoint_result_sha256": hashlib.sha256((root/'proofs/BASEPOINT.json').read_bytes()).hexdigest(),
        "certificates_sha256": certificates,
        "review_gate": "Gate A by Claude is still required before Phase B"
    },
    "unassigned": ["OID numbers", "TLS codepoints", "final X301 input-acceptance/integration baseline"],
    "not_claimed": ["production readiness", "complete v2 signature or XDH implementation", "post-quantum security", "independent pre-run Bitcoin timestamp"]
}

print(json.dumps(data, indent=2))
