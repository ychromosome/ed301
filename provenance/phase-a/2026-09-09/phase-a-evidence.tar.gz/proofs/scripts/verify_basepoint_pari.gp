\\ PARI group-law cross-check of the Python v2 basepoint derivation.
\\ Inputs are the accepted A2 parameters and fresh A5 coordinates, not v1 constants.
default(recover, 0);
default(parisize, 536870912);
default(factor_proven, 1);
p = eval(getenv("ED301_P"));
a = eval(getenv("ED301_A"));
d = eval(getenv("ED301_D"));
q = eval(getenv("ED301_Q"));
px = eval(getenv("ED301_PX"));
py = eval(getenv("ED301_PY"));
gx = eval(getenv("ED301_GX"));
gy = eval(getenv("ED301_GY"));
u_expected = eval(getenv("ED301_U"));
v_expected = eval(getenv("ED301_V"));
if (p != 2^301 - 2^89 + 907 || d != -301, error("v2 parameter identity mismatch"));
if (vecmin([px, py, gx, gy]) < 0 || vecmax([px, py, gx, gy]) >= p, error("noncanonical point coordinates"));
if (px == 0 || gx == 0 || py == 1 || gy == 1, error("exceptional input to regular model map"));
if (px % 2 != 0, error("candidate x parity is not even"));
A = lift(Mod(2*(a+d),p)/Mod(a-d,p));
B = lift(Mod(4,p)/Mod(a-d,p));
E = ellinit([0,Mod(A*B,p),0,Mod(B^2,p),0]);

to_weierstrass(x, y) = {
  my(u = Mod(1+y,p)/Mod(1-y,p), v);
  v = u/Mod(x,p);
  [B*u, B^2*v];
};

P = to_weierstrass(px, py);
G = to_weierstrass(gx, gy);
if (!ellisoncurve(E,P) || !ellisoncurve(E,G), error("point is off Weierstrass curve"));
if (ellmul(E,P,4) != G, error("cofactor clearing differs from Python result"));
if (ellmul(E,G,q) != [0], error("q does not annihilate basepoint"));
ordG = ellorder(E,G,[4*q,[2,2;q,1]]);
if (ordG != q, error("basepoint exact order mismatch"));
u = lift(Mod(1+gy,p)/Mod(1-gy,p));
v = lift(Mod(u,p)/Mod(gx,p));
if (u != u_expected || v != v_expected, error("Montgomery coordinates differ"));
if (lift(Mod(B*v^2-(u^3+A*u^2+u),p)) != 0, error("Montgomery equation failed"));
print("pari_version=",version());
print("p=",p);
print("a=",a);
print("d=",d);
print("G_x=",gx);
print("G_y=",gy);
print("weierstrass_G_x=",lift(G[1]));
print("weierstrass_G_y=",lift(G[2]));
print("montgomery_u=",u);
print("montgomery_v=",v);
print("four_P_equals_G=1");
print("q_times_G=infinity");
print("ellorder_G=",ordG);
print("pari_basepoint_crosscheck_pass=1");
quit;
