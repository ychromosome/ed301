"""Check A6 numeric data against fresh A2/A3/A5 artifacts; no search is performed."""

import hashlib
import json
import math
import re
from pathlib import Path

root = Path(__file__).resolve().parents[2]
v = json.loads((root / "parameter/ed301-v2.json").read_text())
c = json.loads((root / "evidence/A2_RESULT.json").read_text())["candidate"]
b = json.loads((root / "proofs/BASEPOINT.json").read_text())
spec = (root / "spezifikation/ED301-v2.md").read_text()
p, a, d = (int(c[key]) for key in ("p", "a", "d"))
q, qt = int(c["q"]), int(c["qt"])

def require(ok, message):
    if not ok:
        raise ValueError(message)

require(v["field"]["p_decimal"] == c["p"], "field mismatch")
require(v["edwards"]["a_decimal"] == c["a"] and v["edwards"]["d_decimal"] == c["d"], "Edwards coefficients mismatch")
require(v["group"]["q_decimal"] == c["q"] and v["group"]["order_N_decimal"] == c["N"], "main order mismatch")
require(v["twist"]["q_twist_decimal"] == c["qt"] and v["twist"]["order_decimal"] == c["Nt"], "twist order mismatch")
require(v["field"]["p_hex"] == format(p, "x") and v["field"]["p_little_endian_hex"] == p.to_bytes(38, "little").hex(), "field integer encoding mismatch")
require(v["group"]["q_hex"] == format(q, "x") and v["group"]["q_little_endian_hex"] == q.to_bytes(38, "little").hex(), "order integer encoding mismatch")
require(int(v["field"]["inversion_exponent"]) == p-2, "inverse exponent mismatch")
require(int(v["field"]["square_root_exponent"]) == (p+1)//4, "square-root exponent mismatch")
require(int(v["field"]["square_root_ratio_exponent"]) == (p-3)//4, "sqrt-ratio exponent mismatch")

A, B = int(c["A"]), int(c["B"])
require(v["montgomery"]["A_decimal"] == c["A"] and v["montgomery"]["B_decimal"] == c["B"], "Montgomery mismatch")
require(v["weierstrass"]["coefficients"] == ["0",str(A*B % p),"0",str(B*B % p),"0"], "Weierstrass mismatch")
require(v["twist"]["weierstrass_coefficients"] == ["0",str(2*A*B % p),"0",str(4*B*B % p),"0"], "twist coefficients mismatch")
require(pow(B*B*(A*A-4) % p, (p-1)//2, p) == p-1, "rational 2-torsion discriminant condition failed")
tx = int(v["edwards"]["order_4_point"]["x"])
require(tx*int(c["s"]) % p == 1 and a*tx*tx % p == 1, "order-four witness failed")
require((-a*tx*tx) % p == p-1, "twice order-four point is not T2")
require((p-1)*(p-1) % p == 1, "twice T2 is not identity")

x, y = int(b["basepoint"]["x"]), int(b["basepoint"]["y"])
require(v["basepoint"]["G_edwards_x_decimal"] == str(x) and v["basepoint"]["G_edwards_y_decimal"] == str(y), "basepoint mismatch")
require((a*x*x+y*y-1-d*x*x*y*y) % p == 0, "basepoint off curve")
encoding = bytearray(y.to_bytes(38,"little")); encoding[37] |= (x & 1) << 7
require(bytes(encoding).hex() == v["basepoint"]["G_compressed_edwards_hex"], "compressed point mismatch")
require(encoding[37] & 0x60 == 0, "reserved point bits set")
denominator = (a-d*y*y) % p
x_squared = (1-y*y)*pow(denominator,-1,p) % p
r = pow(x_squared,(p+1)//4,p)
require(r*r % p == x_squared, "compressed point does not decode")
r = r if (r & 1) == (encoding[37] >> 7) else p-r
require(r == x, "decoded point sign mismatch")
u = (1+y)*pow(1-y,-1,p) % p
vv = u*pow(x,-1,p) % p
require(v["basepoint"]["G_montgomery_u_decimal"] == str(u) and v["basepoint"]["G_montgomery_v_decimal"] == str(vv), "basepoint model map mismatch")

# Check the chosen A24 convention against Edwards doubling at the new basepoint.
e = d*x*x*y*y % p
y_double = (y*y-a*x*x)*pow(1-e,-1,p) % p
u_double = (1+y_double)*pow(1-y_double,-1,p) % p
AA, BB = (u+1)**2 % p, (u-1)**2 % p
E = (AA-BB) % p
A24 = int(v["montgomery"]["A24_minus_decimal"])
z_double = E*(AA+A24*E) % p
require(AA*BB*pow(z_double,-1,p) % p == u_double, "A24-minus doubling convention mismatch")
require(A24 == (A-2)*pow(4,-1,p) % p, "A24 derivation mismatch")

require(math.prod(int(f)**e for f,e in v["group"]["q_minus_1_factorization"]) == q-1, "q-1 factorization mismatch")
require(math.prod(int(f)**e for f,e in v["twist"]["q_minus_1_factorization"]) == qt-1, "qt-1 factorization mismatch")
require(int(v["weierstrass"]["frobenius_discriminant"]) == int(c["t"])**2-4*p, "Frobenius discriminant mismatch")
require(int(v["weierstrass"]["fundamental_cm_discriminant"])*94**2 == int(c["t"])**2-4*p, "CM decomposition mismatch")
for name, expected_hash in v["evidence"]["certificates_sha256"].items():
    require(hashlib.sha256((root/"proofs/certificates"/name).read_bytes()).hexdigest() == expected_hash, "certificate digest mismatch")

spec_values = {
    "p_decimal":c["p"], "d_canonical":c["d"], "N":c["N"], "q":c["q"],
    "N_twist":c["Nt"], "q_twist":c["qt"], "A_decimal":c["A"], "B_decimal":c["B"],
    "G_x":str(x), "G_y":str(y), "G_compressed_hex":encoding.hex(),
    "G_montgomery_u":str(u), "G_montgomery_v":str(vv),
    "A24_minus_decimal":str(A24)
}
for key, expected in spec_values.items():
    found = re.findall(r"^"+re.escape(key)+r" = ([^\\n]+)$", spec, re.MULTILINE)
    require(found == [expected], "specification value mismatch: "+key)

print(json.dumps({"status":"PASS", "checks":["A2 parameter binding", "integer and point encodings", "field exponents", "model coefficients", "torsion structure", "basepoint decompression and maps", "A24 minus convention", "factor recomposition", "CM relation", "certificate hashes", "specification numeric agreement"], "parameter_sha256":hashlib.sha256((root/"parameter/ed301-v2.json").read_bytes()).hexdigest(), "specification_sha256":hashlib.sha256((root/"spezifikation/ED301-v2.md").read_bytes()).hexdigest()},indent=2))
