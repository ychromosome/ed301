\\ Generate one independently checkable certificate for an A2-derived prime.
\\ Adapted from the v1 phase_a_primecert.gp workflow; no curve parameters are embedded.
\\ Inputs: ED301_CERT_N, ED301_CERT_LABEL, ED301_CERT_KIND (0 ECPP, 1 N-1), ED301_OUT.
default(recover, 0);
default(timer, 0);
default(parisize, 536870912);
default(parisizemax, 4294967296);
default(factor_proven, 1);

n = eval(getenv("ED301_CERT_N"));
label = getenv("ED301_CERT_LABEL");
kind = eval(getenv("ED301_CERT_KIND"));
outdir = getenv("ED301_OUT");
if (type(n) != "t_INT" || n < 2, error("invalid certificate root"));
if (kind != 0 && kind != 1, error("invalid certificate kind"));
if (label != "p" && label != "q" && label != "q_twist", error("invalid certificate label"));

print("pari_version=", version());
print("label=", label);
print("certificate_root=", n);
print("certificate_kind=", kind);
t0 = getwalltime();
cert = primecert(n, kind);
if (cert == 0, error("certificate generation returned composite"));
stem = Str(label, if(kind == 0, "_ecpp", "_nminus1_bls"));

write_output(suffix, value) = {
  my(fd = fileopen(Str(outdir, "/", stem, suffix), "w"));
  filewrite(fd, value);
  fileclose(fd);
};

export_certificate() = {
if (kind == 0,
  if (type(cert) != "t_VEC" || cert[1][1] != n, error("ECPP root mismatch"));
  if (!primecertisvalid(cert), error("generated ECPP certificate is invalid"));
  write_output("_internal.pari", cert);
  write_output("_human.txt", primecertexport(cert, 0));
  write_output("_primo.txt", primecertexport(cert, 1));
  write_output("_magma.m", primecertexport(cert, 2));
  print("ecpp_steps=", #cert);
  last = cert[#cert];
  terminal = (last[1] + 1 - last[2]) / last[3];
  print("terminal_prime=", terminal);
  print("terminal_prime_bitlength=", logint(terminal, 2) + 1);
  print("pari_ecpp_certificate_valid=1");
,
  if (type(cert) != "t_VEC" || cert[1] != n, error("N-1 root mismatch"));
  write_output("_internal.pari", cert);
  print("nminus1_independent_validation=pending");
);
};
export_certificate();
print("generation_ms=", getwalltime() - t0);
print("certificate_generation_pass=1");
quit;
