"""Read-only checks of the fresh A3 report and its exact-order witnesses."""

import ast
import hashlib
import json
import math
from pathlib import Path

if not __debug__:
    raise SystemExit("run this checker without Python optimization")

root = Path(__file__).resolve().parents[1]
path = root / "audit/audit_v3_d-301_c246492_pari.txt"
data = path.read_bytes()
lines = data.decode().splitlines()
pairs = [line.split("=", 1) for line in lines]
assert all(len(pair) == 2 for pair in pairs)
v = dict(pairs)
assert len(v) == len(pairs)
assert lines[-1] == "audit_pass=1" and lines.count("audit_pass=1") == 1
assert data == (root / "evidence/audit.stdout.log").read_bytes()
err = (root / "evidence/audit.stderr.log").read_text().splitlines()
assert len(err) == 2 and all("Warning:" in line and "stack size" in line for line in err)
c = json.loads((root / "evidence/A2_RESULT.json").read_text())["candidate"]
for field in ("p", "c", "s", "a", "q", "qt", "N"):
    assert v[field] == c[field]
assert v["d"] == "-301" and v["N_twist"] == c["Nt"] and v["trace"] == c["t"]
for field in ("p_isprime", "q_isprime", "qt_isprime", "four_q_ge_2pow301",
              "twist_relation_pass", "factor_q_minus_1_complete", "factor_qt_minus_1_complete",
              "hasse_pass", "fundamental_cm_discriminant_is_fundamental",
              "field_modulus_pseudo_mersenne_relation_pass"):
    assert v[field] == "1", field
for field in ("anomalous_curve", "anomalous_twist", "supersingular_curve", "supersingular_twist",
              "j_is_zero", "j_is_1728"):
    assert v[field] == "0", field
assert v["q_bitlength"] == "300" and v["qt_bitlength"] == "299"
assert v["edwards_a_legendre"] == "1" and v["edwards_d_legendre"] == "-1"
assert v["montgomery_A_squared_minus_4_legendre"] == "-1"
for group, field, proof_field, witness_field, order_field in (
    ("q", "factor_q_minus_1", "factor_q_minus_1_prime_proofs",
     "embedding_degree_q_prime_divisor_witnesses", "embedding_degree_q"),
    ("qt", "factor_qt_minus_1", "factor_qt_minus_1_prime_proofs",
     "embedding_degree_qt_prime_divisor_witnesses", "embedding_degree_qt"),
):
    rows = [tuple(int(x.strip()) for x in row.split(",")) for row in v[field][1:-1].split(";")]
    assert all(len(row) == 2 and row[0] > 1 and row[1] > 0 for row in rows)
    assert len(set(r for r, e in rows)) == len(rows)
    assert math.prod(r**e for r, e in rows) == int(v[group]) - 1
    assert ast.literal_eval(v[proof_field]) == [1] * len(rows)
    k, prime, p = int(v[order_field]), int(v[group]), int(v["p"])
    assert pow(p, k, prime) == 1 and k > 100
    witnesses = ast.literal_eval(v[witness_field])
    assert {r for r, value in witnesses} == {r for r, e in rows if k % r == 0}
    assert all(value == pow(p, k//r, prime) and value != 1 for r, value in witnesses)
assert int(v["trace"])**2 - 4*int(v["p"]) == int(v["fundamental_cm_discriminant"])*int(v["frobenius_conductor"])**2
assert ast.literal_eval(v["possible_endomorphism_ring_conductors"]) == [1, 2, 47, 94]
assert hashlib.sha256(data).hexdigest() == json.loads((root / "evidence/A3_RESULT.json").read_text())["report_sha256"]
print("fresh_A3_report_verification=PASS")
