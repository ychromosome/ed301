# Gate A1 – Prüfung des Veröffentlichungspakets, Freigabe

Prüfer: Claude. Datum: 9. September 2026. Gegenstand: Branch `Review` von
https://github.com/ychromosome/ed301, Verzeichnis `provenance/v2-search/`.

| Bindung | Wert |
|---|---|
| Freigegebener Commit | `0bf9b5936737fc920d701815cf55cfd35c54d288` (Martin Wolf, 2026-09-09 19:44:30 +0200, „Prepare v2 search precommitment for review“) |
| SHA-256 `RUN_MANIFEST.sha256` | `a9c210823af851675678117d401415b54c2ad0cad8bb4ab47ce94f669acae313` |
| SHA-256 `REGELDATEI_ED301-v2.md` | `b5e9c6d49641f2181c3d5635b7827814c799d924ffcfbc7cdbeb9bbb61cdab7a` |

## Geprüft, alles bestanden

- `sha256sum --check RUN_MANIFEST.sha256`: 17 Dateien OK, keine Abweichung.
- `search_worker_v3.gp`, `search_v3.py`, `audit_v3_template.gp`: byteidentisch mit den
  freigegebenen Fassungen aus der Übergabe (Hashes b4ef9d04…, f7579311…, 2b51c973…).
- `REGELDATEI_ED301-v2.md`: Abschnitt 3 (neun Annahmekriterien, Reihenfolge) wörtlich
  unverändert gegenüber dem geprüften Entwurf 461f7ea8…; Änderungen nur in Kopf,
  Offenlegung, Abschnitt 4 (Hashbindung, fester A2-Aufruf, Abnahme aus Rohdateien plus
  JSONL) und Abschnitt 5 (Basispunkt). Keine Änderung des Annahmeprädikats.
- Basispunktverfahren in Abschnitt 5 gegen `reference/ED301-v1.md` §10 und das
  v1-Ableitungsskript verglichen: DST 29 Byte, Zähler 4 Byte big-endian, SHAKE256/38,
  `candidate[37] &= 0x1f`, `y < p`, gerade x-Parität, `G = [4]P`, `G ≠ O`, erster Zähler,
  Erschöpfung ist Fehler. Identisch bis auf DST-Suffix und Parameter.
- `RUN_PARAMETERS.json`: Aufruf `--d -301 --start 0 --chunk 64 --workers 10 --maximum 1000000
  --out raw_v3`; erwarteter Treffer 246492 im Block [246464, 246527] (stimmt); Erfolgskriterien
  strenger als `status=OK`; Kandidat für A3 aus dem frischen Lauf, nicht aus der Vorhersage.
- `EXPECTED_CANDIDATE.json`: alle 14 Werte identisch mit `ED301-v2_candidate_values.json`.
- `exploration.tar.gz`: 7448 Einträge, keine absoluten Pfade, keine Traversal; enthält alle
  Schlüsselartefakte (COVERAGE.md, STATUS.md, beide Kandidaten-JSON, v2- und v3-Audits,
  Kontrollläufe, alle Worker/Treiber-Fassungen, Regeldatei-Entwurf) und die Rohblöcke aller
  Phasen (d=145: 222/192/1383, d=89: 1291, d=−301: 1335/176/2782 Dateien).
- `EXPLORATION.md`: Abdeckungstabelle stimmt mit meiner `COVERAGE.md` überein; Grenzen
  (kein neuer Punktzählnachweis, kein Beleg der historischen Laufumgebung) korrekt benannt;
  Korrekturgeschichte der Audits korrekt.
- `TOOL_VERSIONS.txt`: PARI 2.17.4, seadata 20090618, Python 3.14.7, als Referenz gekennzeichnet.
- `README.md`, A1-Ablauf: signierter Tag durch Martin auf diesem Commit, GitHub-Prerelease mit
  `published_at`, OpenTimestamps mit vollständiger Bitcoin-Verifikation vor A2, Beleg später
  getrennt archiviert, Tag nie verschieben. Strenger als meine Empfehlung, sachlich richtig.
- `AGENTS.md`: Branch-Rollen, Signaturverbot für Assistenten, Phasenschranke. Passt zu Auftrag
  und Vorabfragen.

## Befunde

Keine der Klasse „hoch“ oder „mittel“. Nits ohne Änderungsbedarf vor dem Tag: keine.

## Freigabe

Gate A1 ist aus Prüfersicht frei. Martin kann den annotierten, GPG-signierten Tag auf
`0bf9b5936737fc920d701815cf55cfd35c54d288` setzen, das Prerelease anlegen und das Manifest mit
OpenTimestamps stempeln. Jede Änderung am Paket nach diesem Zeitpunkt erfordert eine neue
Prüfung und neue Hashes.

## Nachtrag: Veröffentlichung verifiziert (2026-09-09, 20:2x CEST)

- Tag `v2-search-rule-2026-09-09` zeigt auf `0bf9b5936737fc920d701815cf55cfd35c54d288`
  (annotiertes Tag-Objekt); GPG-Signatur korrekt, RSA-Schlüssel
  `A1A573F04786BE9FF8A6BF7C109858B57B6B73BA`, Martin Wolf, signiert 20:00:27 CEST.
- GitHub-Release id 385742722 zu diesem Tag, `prerelease=true`, serverseitiges
  `published_at = 2026-09-09T18:11:30Z` (20:11:30 CEST). Das Feld `target_commitish=main`
  ist bei bereits vorhandenem Tag nur informativ; die Bindung läuft über das Tag-Objekt.
- OpenTimestamps entfällt per Entscheidung Martin; externer Zeitnachweis ist damit allein
  der GitHub-Serverzeitstempel des Prereleases. Die mathematischen Prüfungen bleiben
  unverändert.
- A2 gestartet 20:14:16 CEST, also nach der Veröffentlichung; Reihenfolge eingehalten.
- Nachtrag: Martin hat das Manifest doch mit OpenTimestamps gestempelt (Stempelzeitpunkt nach dem
  Prerelease; `ots upgrade` und Ablage der `.ots` in einem eigenen Commit unter `provenance/phase-a/`
  stehen noch aus). Damit gibt es zwei unabhängige Zeitnachweise; der GitHub-Zeitstempel bleibt der
  frühere.
