"""Read-only check of the fresh A2 block records; no search or point counting."""

import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
raw_dir = root / "run" / "raw_v3"
jsonl_path = raw_dir / "search_v3_d-301_from0.jsonl"
stdout_path = root / "evidence" / "driver.stdout.log"
stderr_path = root / "evidence" / "driver.stderr.log"
source = root / "source" / "provenance" / "v2-search"
parameters = json.loads((source / "RUN_PARAMETERS.json").read_text())
prediction = json.loads((source / "EXPECTED_CANDIDATE.json").read_text())

jsonl = jsonl_path.read_bytes()
assert jsonl.endswith(b"\n"), "incomplete final JSONL record"
records = [json.loads(line) for line in jsonl.splitlines()]
assert records, "no completed blocks"
assert not stderr_path.read_bytes().strip(), "driver stderr is not empty"

intervals = {}
seen_files = set()
hits = []
raw_hashes = {}
expected_fields = {
    "rule", "d", "counter_start", "counter_end", "tested", "elapsed_ms", "hits"
}
rule_marker = "REGELDATEI_ED301-v2 section 3, worker search_worker_v3.gp"

for record in records:
    assert record["ok"] is True and record["rc"] == 0 and not record["err"]
    start, end, worker = record["start"], record["end"], record["wid"]
    assert all(type(value) is int for value in (start, end, worker))
    assert start >= 0 and start % 64 == 0 and end == start + 63
    assert 0 <= worker < 10
    assert (start, end) not in intervals, "duplicate completed interval"
    name = f"search_v3_d-301_{start}_{end}_worker_{worker}.txt"
    assert record["raw"] == name and name not in seen_files
    seen_files.add(name)
    payload = (raw_dir / name).read_bytes()
    raw_hashes[name] = hashlib.sha256(payload).digest()
    assert payload.endswith(b"\n"), "incomplete raw file"
    pairs = [line.split("=", 1) for line in payload.decode().splitlines()]
    assert all(len(pair) == 2 for pair in pairs)
    values = dict(pairs)
    assert len(pairs) == len(values) == 7 and set(values) == expected_fields
    assert values["rule"] == rule_marker and int(values["d"]) == -301
    assert int(values["counter_start"]) == start
    assert int(values["counter_end"]) == end and int(values["tested"]) == 64
    assert int(values["elapsed_ms"]) >= 0
    block_hits = json.loads(values["hits"])
    assert block_hits == [json.loads(value) for value in record["hits"]]
    for hit in block_hits:
        assert len(hit) == 11 and all(type(value) is int for value in hit)
        assert start <= hit[0] <= end
        hits.append(hit)
    intervals[start, end] = name

assert {path.name for path in raw_dir.iterdir()} == seen_files | {jsonl_path.name}
cursor = 0
for start, end in sorted(intervals):
    assert start == cursor, f"gap or overlap at {cursor}"
    cursor = end + 1
assert hits, "no valid hit"
hits.sort(key=lambda hit: hit[0])
winner = hits[0]
assert winner[0] == parameters["expected_first_counter"] == 246492
assert parameters["expected_winning_block"] == [246464, 246527]
assert cursor > parameters["expected_winning_block"][1]

p = 2**301 - 2**89 + 907
d = -301
names = ("c", "s", "a", "A", "B", "N", "q", "Nt", "qt", "t", "DK")
candidate = dict(zip(names, winner))
assert candidate["s"] == 907 + candidate["c"]
assert candidate["a"] == candidate["s"] ** 2 % p
inverse = pow(candidate["a"] - d, -1, p)
assert candidate["A"] == 2 * (candidate["a"] + d) * inverse % p
assert candidate["B"] == 4 * inverse % p
assert candidate["N"] == 4 * candidate["q"]
assert candidate["Nt"] == 4 * candidate["qt"]
assert candidate["N"] + candidate["Nt"] == 2 * p + 2
assert candidate["t"] == p + 1 - candidate["N"]
assert candidate["t"] ** 2 <= 4 * p
assert candidate["q"].bit_length() == 300
assert candidate["qt"].bit_length() >= 299
assert candidate["N"] >= 2**301
candidate.update(p=p, p_hex=hex(p), d=p + d)
assert set(candidate) == set(prediction)
assert all(str(value) == prediction[name] for name, value in candidate.items())

stdout = stdout_path.read_bytes()
lines = stdout.decode().splitlines()
summaries = [line for line in lines if line.startswith("SUMMARY ")]
assert len(summaries) == 1 and lines[-1] == summaries[0]
assert not any(line.startswith("FATAL") for line in lines)
summary = summaries[0]
assert re.search(r"^SUMMARY d=-301 status=OK ", summary)
assert f"contiguous_through={cursor-1} " in summary
assert f"completed_chunks={len(records)} " in summary
assert "failed_chunks=[] " in summary
summary_hits = json.loads(summary.split(" hits=", 1)[1])
assert sorted((json.loads(value) for _, value in summary_hits), key=lambda h: h[0]) == hits
assert len([line for line in lines if line.startswith("CHUNK ")]) == len(records)

aggregate = hashlib.sha256()
for name in sorted(raw_hashes):
    aggregate.update(name.encode() + b"\0" + raw_hashes[name])

print(json.dumps({
    "status": "PASS",
    "verification_scope": "Fresh block records, metadata, coverage, numeric first hit and candidate algebra; no independent point count or primality certificate verification in this checker",
    "completed_blocks": len(records),
    "covered_counters": [0, cursor - 1],
    "tested_counter_count": cursor,
    "failed_blocks": 0,
    "hit_count": len(hits),
    "first_valid_counter": winner[0],
    "winning_block": [246464, 246527],
    "prediction_matches_all_14_values": True,
    "candidate": {name: str(value) for name, value in candidate.items()},
    "raw_record_aggregate_sha256": aggregate.hexdigest(),
    "raw_aggregate_method": "Lexicographically sorted basename, NUL, binary SHA-256(file), concatenated into SHA-256",
    "jsonl_sha256": hashlib.sha256(jsonl).hexdigest(),
    "stdout_sha256": hashlib.sha256(stdout).hexdigest(),
    "stderr_sha256": hashlib.sha256(stderr_path.read_bytes()).hexdigest(),
}, indent=2))
